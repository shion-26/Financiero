# -*- coding: utf-8 -*-
import base64
import logging
import os
from datetime import datetime

from odoo import api, fields, models
from odoo.exceptions import UserError

from ..services.excel_reader import ExcelReader
from ..services.txt_generator import build_inspection_report, generate_txt

_logger = logging.getLogger(__name__)


class GenerarTxtWizard(models.TransientModel):
    _name = 'financiero.generar.txt'
    _description = 'Generador TXT Medios Magnéticos'

    anio = fields.Char(string='Año', default='2025', required=True)
    formato = fields.Selection(
        [
            ('5247', '5247'),
            ('5248', '5248'),
            ('5249', '5249'),
            ('5250', '5250'),
            ('5251', '5251'),
            ('5252', '5252'),
        ],
        string='Formato',
        default='5247',
        required=True,
    )
    codigo_formato = fields.Char(string='Código formato', default='1009')
    codigo_concepto = fields.Char(string='Código concepto', default='2215')

    archivo_excel = fields.Binary(string='Archivo Excel (.xlsx)', required=True)
    nombre_archivo = fields.Char(string='Nombre archivo')
    hoja_datos = fields.Char(
        string='Hoja de datos',
        help='Vacío = detectar automáticamente (ignora hojas "Formato XXXX")',
    )

    estado = fields.Selection(
        [
            ('draft', 'Borrador'),
            ('inspected', 'Inspeccionado'),
            ('done', 'Generado'),
            ('error', 'Error'),
        ],
        default='draft',
        readonly=True,
    )
    log_resultado = fields.Text(string='Log', readonly=True)
    total_lineas = fields.Integer(string='Líneas', readonly=True)
    longitud_linea = fields.Integer(string='Longitud línea', readonly=True)

    archivo_txt = fields.Binary(string='Archivo TXT', readonly=True)
    archivo_txt_nombre = fields.Char(string='Nombre TXT', readonly=True)

    def _get_excel_bytes(self):
        self.ensure_one()
        if not self.archivo_excel:
            raise UserError('Debe seleccionar un archivo Excel (.xlsx).')
        return base64.b64decode(self.archivo_excel)

    def _validate_extension(self):
        self.ensure_one()
        if self.nombre_archivo:
            ext = os.path.splitext(self.nombre_archivo)[1].lower()
            if ext and ext != '.xlsx':
                raise UserError(
                    f'Formato "{ext}" no soportado. Use archivos .xlsx '
                    '(openpyxl). No use .xls ni xlrd.'
                )

    def _wizard_context(self):
        self.ensure_one()
        return {
            'ANIO': (self.anio or '2025').strip(),
            'FORMATO': (self.codigo_formato or '').strip(),
            'CONCEPTO': (self.codigo_concepto or '').strip(),
        }

    def action_inspeccionar(self):
        self.ensure_one()
        self._validate_extension()
        try:
            reader = ExcelReader(self._get_excel_bytes())
            report, hoja_sugerida = build_inspection_report(reader, self.formato)
            vals = {'estado': 'inspected', 'log_resultado': report}
            if hoja_sugerida and not self.hoja_datos:
                vals['hoja_datos'] = hoja_sugerida
            self.write(vals)
        except UserError:
            raise
        except Exception as exc:
            _logger.exception('Error inspeccionando Excel')
            self.write({'estado': 'error', 'log_resultado': str(exc)})
            raise UserError(str(exc)) from exc
        return self._reopen()

    def action_generar_txt(self):
        self.ensure_one()
        self._validate_extension()

        if self.formato != '5247':
            raise UserError(
                f'Formato {self.formato} aún no está implementado. '
                'Solo 5247 está disponible por ahora.'
            )

        try:
            result = generate_txt(
                self.archivo_excel,
                self.formato,
                sheet_name=self.hoja_datos or None,
                context=self._wizard_context(),
            )
        except UserError:
            raise
        except ValueError as exc:
            raise UserError(str(exc)) from exc
        except Exception as exc:
            _logger.exception('Error generando TXT')
            self.write({'estado': 'error', 'log_resultado': str(exc)})
            raise UserError(f'Error al generar TXT: {exc}') from exc

        if result['line_count'] == 0:
            raise UserError(
                'No se generó ninguna línea. Use "Inspeccionar" para ver las hojas '
                'disponibles e indique la hoja de datos correcta.'
            )

        fecha = datetime.now().strftime('%Y%m%d_%H%M%S')
        nombre_txt = f'medios_{self.formato}_{fecha}.txt'
        log = [
            'TXT generado.',
            f"  Hoja usada: {result['sheet_used']}",
            f"  Líneas: {result['line_count']}",
            f"  Longitud/línea: {result['line_length']} (esperado ~765 cuando esté completo el SQL)",
        ]
        if result['errors']:
            log.append(f"  Advertencias: {len(result['errors'])}")
            log.extend(result['errors'][:10])

        self.write({
            'estado': 'done',
            'archivo_txt': base64.b64encode(result['content'].encode('latin-1')),
            'archivo_txt_nombre': nombre_txt,
            'total_lineas': result['line_count'],
            'longitud_linea': result['line_length'],
            'log_resultado': '\n'.join(log),
        })
        return self._reopen()

    def action_descargar_txt(self):
        self.ensure_one()
        if not self.archivo_txt:
            raise UserError('Genere el TXT primero.')
        return {
            'type': 'ir.actions.act_url',
            'url': (
                f'/web/content/?model={self._name}&id={self.id}'
                f'&field=archivo_txt&filename_field=archivo_txt_nombre&download=true'
            ),
            'target': 'self',
        }

    def _reopen(self):
        return {
            'type': 'ir.actions.act_window',
            'name': 'Generar TXT',
            'res_model': self._name,
            'res_id': self.id,
            'view_mode': 'form',
            'target': 'new',
        }
