# -*- coding: utf-8 -*-
import openpyxl
from odoo.exceptions import UserError


def _normalize(value):
    """Normalizar nombres de campos: espacios, mayúsculas, guiones bajos"""
    return str(value or '').strip().upper().replace(' ', '_').replace('-', '_')


class ExcelParser:
    def __init__(self, contenido, nombre_archivo):
        """
        Parser para archivos Excel que definen la estructura de campos
        
        Args:
            contenido: bytes del archivo Excel
            nombre_archivo: nombre del archivo para referencia
        """
        self.nombre_archivo = nombre_archivo
        self.contenido = contenido
        self.wb = None
        self._cargar_excel()

    def _cargar_excel(self):
        """Cargar y validar el archivo Excel"""
        try:
            from io import BytesIO
            self.wb = openpyxl.load_workbook(BytesIO(self.contenido))
        except Exception as e:
            raise UserError(f"Error al cargar Excel: {str(e)}")

    def obtener_campos(self):
        """
        Extraer definición de campos del Excel
        
        Retorna: {
            'campos': [
                {
                    'nombre': 'TERCERO',
                    'inicio': 1,
                    'tamano': 20,
                    'tipo': 'Texto',
                    'obligatorio': True
                },
                ...
            ],
            'longitud_total': 500
        }
        """
        if not self.wb:
            raise UserError("Excel no cargado")

        ws = self.wb.active
        campos = []
        longitud_total = 0

        # Asumir que la primera fila contiene headers
        # Columnas: Nombre | Inicio | Tamaño | Tipo | Obligatorio
        for row_idx, row in enumerate(ws.iter_rows(min_row=2, values_only=True), start=2):
            if not row[0]:  # Fin de datos
                break

            try:
                nombre = _normalize(row[0])
                inicio = int(row[1] or 0)
                tamano = int(row[2] or 0)
                tipo = str(row[3] or 'Texto').strip()
                obligatorio = str(row[4] or 'No').upper() in ('SI', 'YES', 'TRUE', '1')

                if not nombre or not inicio or not tamano:
                    continue

                campos.append({
                    'nombre': nombre,
                    'inicio': inicio,
                    'tamano': tamano,
                    'tipo': tipo,
                    'obligatorio': obligatorio
                })

                longitud_total = max(longitud_total, inicio + tamano - 1)

            except (ValueError, TypeError) as e:
                raise UserError(f"Error en fila {row_idx}: {str(e)}")

        if not campos:
            raise UserError("No se encontraron campos en el Excel")

        return {
            'campos': campos,
            'longitud_total': longitud_total
        }
