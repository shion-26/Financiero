# -*- coding: utf-8 -*-

from ..padding import oracle_entero, rpad

def campo_texto(valor, longitud):
    return rpad(valor or '', longitud, ' ')

def campo_num(valor, longitud):
    return oracle_entero(valor, longitud, '0')

def render_line_5247(row, context=None):

    ctx = context or {}

    anio = ctx.get('ANIO', '2025')
    formato = ctx.get('FORMATO', '1009')
    concepto = ctx.get('CONCEPTO', '2215')

    tercero = (
        row.get('NUMERO_DOCUMENTO')
        or row.get('NIT')
        or row.get('DOCUMENTO')
        or ''
    )

    valor1 = row.get('VALOR', 0)
    valor5 = row.get('VALOR2', 0)

    linea = ''

    # 1-24
    linea += campo_texto(anio, 4)
    linea += campo_texto(formato, 10)
    linea += campo_texto(concepto, 10)

    # 25-39
    linea += campo_texto(tercero, 15)

    # 40-74
    linea += campo_texto('', 15)
    linea += campo_texto('', 20)

    # 75-254
    linea += campo_num(valor1, 20)

    linea += campo_num(0, 20)
    linea += campo_num(0, 20)
    linea += campo_num(0, 20)

    linea += campo_num(valor5, 20)

    linea += campo_num(0, 20)
    linea += campo_num(0, 20)
    linea += campo_num(0, 20)
    linea += campo_num(0, 20)

    # 255-260
    linea += campo_texto('', 2)
    linea += campo_texto('', 4)

    # 261-300
    linea += campo_num(0, 20)
    linea += campo_num(0, 20)

    # VALOR12-VALOR30
    for _ in range(19):
        linea += campo_num(0, 20)

    # 681-685
    linea += campo_num(0, 5)

    # 686-693
    linea += campo_texto('', 8)

    # 694-703
    linea += campo_texto('', 10)

    # 704-708
    linea += campo_num(0, 5)

    # 709-716
    linea += campo_texto('', 8)

    # 717-756
    linea += campo_texto('', 40)

    # 757-759
    linea += campo_texto('', 3)

    # 760-765
    linea += campo_num(0, 6)

    return linea

FORMAT_5247 = {
    'code': '5247',
    'label': 'Formato 5247',
    'line_length': 765,
    'render_line': render_line_5247,
}

