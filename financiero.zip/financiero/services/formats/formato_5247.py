# -*- coding: utf-8 -*-
from ..padding import lpad, rpad, oracle_entero

COLUMN_ALIASES = {
    'ANIO': ['ANIO', 'AÑO', 'ANO', 'YEAR'],
    'FORMATO': ['FORMATO', 'COD_FORMATO'],
    'CONCEPTO': ['CONCEPTO', 'COD_CONCEPTO'],
    'NUMERO_DOCUMENTO': [
        'NUMERO_DOCUMENTO', 'TERCERO', 'NIT', 'DOCUMENTO',
        'NUM_DOCUMENTO', 'ID_TERCERO',
    ],
    'VALOR': ['VALOR', 'VALOR1', 'VALOR_1', 'IMPORTE', 'VALOR_TOTAL'],
}


def _resolve(row, key, defaults):
    if key in row and row[key] not in (None, ''):
        return row[key]
    for alias in COLUMN_ALIASES.get(key, [key]):
        norm = alias.upper().replace(' ', '_')
        if norm in row and row[norm] not in (None, ''):
            return row[norm]
    return defaults.get(key)


def _render_field(field, row, ctx):
    ftype = field.get('type', 'text')
    width = field['width']
    fill = field.get('fill', ' ')

    if ftype == 'literal':
        raw = field.get('literal', '')
    elif ftype == 'numeric_oracle':
        return oracle_entero(_resolve(row, field['key'], ctx), width, fill)
    else:
        key = field.get('key')
        raw = _resolve(row, key, ctx) if key else field.get('default', '')
        if raw is None:
            raw = ''

    text = str(raw)
    if fill == '0':
        return lpad(text, width, fill)
    return rpad(text, width, fill)


FORMAT_5247 = {
    'code': '5247',
    'label': 'Formato 5247',
    'line_length': 765,
    'defaults': {
        'ANIO': '2025',
        'FORMATO': '1009',
        'CONCEPTO': '2215',
    },
    'fields': [
        {'key': 'ANIO', 'width': 4, 'type': 'text', 'fill': ' '},
        {'key': 'FORMATO', 'width': 10, 'type': 'text', 'fill': ' '},
        {'key': 'CONCEPTO', 'width': 10, 'type': 'text', 'fill': ' '},
        {'key': 'NUMERO_DOCUMENTO', 'width': 15, 'type': 'text', 'fill': ' '},
        {'width': 15, 'type': 'literal', 'literal': '', 'fill': ' '},
        {'width': 20, 'type': 'literal', 'literal': '', 'fill': ' '},
        {'key': 'VALOR', 'width': 20, 'type': 'numeric_oracle', 'fill': '0'},
    ],
}


def render_line_5247(row, context=None):
    ctx = dict(FORMAT_5247['defaults'])
    if context:
        ctx.update({k.upper(): v for k, v in context.items()})
    parts = [_render_field(f, row, ctx) for f in FORMAT_5247['fields']]
    line = ''.join(parts)
    expected = FORMAT_5247['line_length']
    if len(line) < expected:
        line += rpad('', expected - len(line), ' ')
    elif len(line) > expected:
        line = line[:expected]
    return line


FORMAT_5247['render_line'] = render_line_5247
