# -*- coding: utf-8 -*-
import base64
import io
import logging
import re

from odoo.exceptions import UserError

_logger = logging.getLogger(__name__)

try:
    import openpyxl
except ImportError:
    openpyxl = None


def _normalize_header(value):
    if value is None:
        return ''
    text = str(value).strip().upper()
    return re.sub(r'\s+', '_', text)


class ExcelReader:
    """Lee archivos .xlsx con openpyxl (no usar xlrd para xlsx)."""

    def __init__(self, file_bytes):
        if openpyxl is None:
            raise UserError(
                'Falta openpyxl en el servidor. Instálelo con: pip install openpyxl'
            )
        if not file_bytes:
            raise UserError('No hay contenido de archivo para leer.')
        self._bytes = file_bytes
        self._wb = None

    def _load_workbook(self):
        if self._wb is not None:
            return self._wb
        try:
            self._wb = openpyxl.load_workbook(
                io.BytesIO(self._bytes),
                read_only=True,
                data_only=True,
            )
        except Exception as exc:
            _logger.exception('Error abriendo Excel')
            raise UserError(
                f'No se pudo abrir el archivo Excel (.xlsx): {exc}'
            ) from exc
        return self._wb

    def list_sheet_names(self):
        return list(self._load_workbook().sheetnames)

    def inspect_workbook(self):
        report = []
        for name in self.list_sheet_names():
            ws = self._load_workbook()[name]
            headers, row_count, is_format_def = self._scan_sheet(ws)
            report.append({
                'name': name,
                'headers': headers,
                'data_rows': row_count,
                'is_format_definition': is_format_def,
            })
        return report

    def _scan_sheet(self, ws, max_scan_rows=500):
        headers = []
        header_row_idx = None
        row_count = 0

        for idx, row in enumerate(
            ws.iter_rows(min_row=1, max_row=max_scan_rows, values_only=True),
            start=1,
        ):
            if not row or all(c is None or str(c).strip() == '' for c in row):
                continue
            normalized = [_normalize_header(c) for c in row]
            if not headers and any(normalized):
                headers = normalized
                header_row_idx = idx
                continue
            if header_row_idx and idx > header_row_idx:
                row_count += 1

        is_format_def = (
            'INICIO' in headers
            and ('TAMAÑO' in headers or 'TAMANO' in headers)
        )
        return headers, row_count, is_format_def

    def resolve_data_sheet(self, sheet_name=None, formato_code=None):
        """Devuelve el nombre de la hoja con datos (no la spec Siesa 'Formato XXXX')."""
        wb = self._load_workbook()
        if sheet_name:
            if sheet_name not in wb.sheetnames:
                available = ', '.join(wb.sheetnames)
                raise UserError(
                    f'La hoja "{sheet_name}" no existe. Hojas disponibles: {available}'
                )
            return sheet_name

        # No buscar "Formato 5247" — esa hoja es documentación, no datos
        candidates = []
        formato_sheet = f'Formato {formato_code}' if formato_code else None

        for name in wb.sheetnames:
            if formato_sheet and name.strip().lower() == formato_sheet.lower():
                continue
            if name.lower().startswith('formato '):
                ws = wb[name]
                _, count, is_def = self._scan_sheet(ws)
                if is_def or count == 0:
                    continue
            ws = wb[name]
            headers, count, is_def = self._scan_sheet(ws)
            if is_def or count == 0 or not headers:
                continue
            candidates.append((name, count))

        if not candidates:
            available = ', '.join(wb.sheetnames)
            raise UserError(
                'No se encontró ninguna hoja con datos. '
                f'Hojas en el archivo: {available}. '
                'Indique manualmente la hoja de datos (no use "Formato XXXX" del Excel Siesa).'
            )
        candidates.sort(key=lambda x: -x[1])
        return candidates[0][0]

    def read_data_rows(self, sheet_name=None, formato_code=None):
        target = self.resolve_data_sheet(sheet_name, formato_code)
        ws = self._load_workbook()[target]
        rows = self._read_sheet_as_dicts(ws)
        for row in rows:
            row['_HOJA_ORIGEN'] = target
        return rows, target

    def _read_sheet_as_dicts(self, ws, header_row=1):
        rows_iter = ws.iter_rows(values_only=True)
        headers = None
        result = []
        for idx, row in enumerate(rows_iter, start=1):
            if idx < header_row:
                continue
            if idx == header_row:
                headers = [_normalize_header(c) for c in row]
                continue
            if not row or all(c is None or str(c).strip() == '' for c in row):
                continue
            record = {}
            for col_idx, key in enumerate(headers):
                if not key:
                    continue
                val = row[col_idx] if col_idx < len(row) else None
                record[key] = val
            if any(v is not None and str(v).strip() != '' for v in record.values()):
                result.append(record)
        return result

    def read_format_definition(self, sheet_name):
        wb = self._load_workbook()
        if sheet_name not in wb.sheetnames:
            return []
        ws = wb[sheet_name]
        fields = []
        col_inicio, col_tamano, col_total = 1, 2, 3

        for row in ws.iter_rows(values_only=True):
            if not row or not row[0]:
                continue
            nombre = _normalize_header(row[0])
            if nombre in ('CAMPO', 'NOMBRE', 'DESCRIPCION'):
                for i, cell in enumerate(row):
                    h = _normalize_header(cell)
                    if h == 'INICIO':
                        col_inicio = i
                    elif h in ('TAMAÑO', 'TAMANO'):
                        col_tamano = i
                    elif h == 'TOTAL':
                        col_total = i
                continue
            if nombre in ('INICIO', 'TAMAÑO', 'TAMANO', 'TOTAL'):
                continue

            def _num(col_idx):
                if col_idx >= len(row):
                    return None
                v = row[col_idx]
                return int(v) if isinstance(v, (int, float)) else None

            inicio = _num(col_inicio)
            tamano = _num(col_tamano)
            total = _num(col_total)
            if inicio is not None and tamano is not None:
                fields.append({
                    'name': nombre,
                    'start': inicio,
                    'size': tamano,
                    'end': total if total else inicio + tamano - 1,
                })
        return fields

    @classmethod
    def from_base64(cls, b64_data):
        if not b64_data:
            raise UserError('Debe cargar un archivo Excel (.xlsx).')
        return cls(base64.b64decode(b64_data))
