# -*- coding: utf-8 -*-
import logging

from .excel_reader import ExcelReader
from .format_registry import get_format

_logger = logging.getLogger(__name__)


def build_inspection_report(reader, formato_code='5247'):
    lines = ['=== INSPECCIÓN DEL ARCHIVO EXCEL ===\n']
    hoja_datos_sugerida = None

    for sheet in reader.inspect_workbook():
        tipo = 'DEFINICIÓN (Siesa)' if sheet['is_format_definition'] else 'DATOS'
        lines.append(f"Hoja: {sheet['name']} [{tipo}]")
        lines.append(f"  Filas de datos: {sheet['data_rows']}")
        if sheet['headers']:
            cols = ', '.join(sheet['headers'][:30])
            lines.append(f"  Columnas: {cols}")
            if len(sheet['headers']) > 30:
                lines.append(f"    ... y {len(sheet['headers']) - 30} más")
        lines.append('')
        if not sheet['is_format_definition'] and sheet['data_rows'] > 0:
            if not hoja_datos_sugerida:
                hoja_datos_sugerida = sheet['name']

    spec_sheet = f'Formato {formato_code}'
    if spec_sheet in reader.list_sheet_names():
        siesa = reader.read_format_definition(spec_sheet)
        if siesa:
            lines.append(f'=== SPEC SIESA ({spec_sheet}) — {len(siesa)} campos ===')
            only_names = [f['name'] for f in siesa[:10]]
            lines.append('  ' + ', '.join(only_names))
            if len(siesa) > 10:
                lines.append(f'  ... y {len(siesa) - 10} más')
            lines.append(
                '\nNOTA: Esta hoja es documentación, NO contiene registros a exportar.'
            )
    else:
        lines.append(
            f'\n(No existe hoja "{spec_sheet}" — normal si subió el Excel financiero, no el Siesa.)'
        )

    if hoja_datos_sugerida:
        lines.append(f'\nHoja de datos sugerida: {hoja_datos_sugerida}')
    else:
        lines.append('\n⚠ No se detectó hoja con datos. Verifique el archivo.')

    return '\n'.join(lines), hoja_datos_sugerida


def generate_txt(file_b64, formato_code, sheet_name=None, context=None):
    reader = ExcelReader.from_base64(file_b64)
    rows, hoja_usada = reader.read_data_rows(
        sheet_name=sheet_name,
        formato_code=formato_code,
    )
    spec = get_format(formato_code)
    render = spec['render_line']
    ctx = context or {}

    lineas = []
    errores = []
    for idx, row in enumerate(rows, start=1):
        try:
            lineas.append(render(row, ctx))
        except Exception as exc:
            errores.append(f'Fila {idx}: {exc}')
            _logger.warning('Error fila %s: %s', idx, exc)

    contenido = '\n'.join(lineas)
    if lineas:
        contenido += '\n'

    return {
        'content': contenido,
        'line_count': len(lineas),
        'errors': errores,
        'line_length': len(lineas[0]) if lineas else 0,
        'sheet_used': hoja_usada,
    }
