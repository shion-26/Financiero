# -*- coding: utf-8 -*-
"""Equivalentes Python de LPAD/RPAD de Oracle."""


def lpad(value, width, fill=' '):
    s = '' if value is None else str(value)
    if len(s) > width:
        return s[-width:]
    return s.rjust(width, fill[0] if fill else ' ')


def rpad(value, width, fill=' '):
    s = '' if value is None else str(value)
    if len(s) > width:
        return s[:width]
    return s.ljust(width, fill[0] if fill else ' ')


def oracle_entero(valor, width=20, fill='0'):
    raw = str(valor or '0').strip() or '0'
    if ',' in raw and '.' in raw:
        raw = raw.replace('.', '').replace(',', '.')
    elif ',' in raw:
        raw = raw.replace(',', '.')
    try:
        numero = round(float(raw))
    except ValueError:
        numero = 0
    return lpad(numero, width, fill)
