"""
Módulo para generación de archivos TXT formato SIESA
Maneja validación, normalización y formateo de registros con posiciones fijas.
"""
"""
Módulo para generación de archivos TXT formato SIESA
Maneja validación, normalización y formateo de registros con posiciones fijas.
"""


class TXTBuilder:
    """Constructor de archivos TXT con estructura SIESA de ancho fijo."""

    # Especificación de campos SIESA (inicio, tamaño, tipo)
    CAMPO_SPECS = {
        'AÑO': {'inicio': 1, 'tamaño': 4, 'tipo': 'numero'},
        'FORMATO': {'inicio': 5, 'tamaño': 10, 'tipo': 'texto'},
        'CONCEPTO': {'inicio': 15, 'tamaño': 10, 'tipo': 'texto'},
        'TERCERO': {'inicio': 25, 'tamaño': 15, 'tipo': 'texto'},
        'MANDANTE': {'inicio': 40, 'tamaño': 15, 'tipo': 'texto'},
        'FIDEICOMISO': {'inicio': 55, 'tamaño': 20, 'tipo': 'texto'},
        'VALOR_1': {'inicio': 75, 'tamaño': 20, 'tipo': 'numero'},
        'VALOR_2': {'inicio': 95, 'tamaño': 20, 'tipo': 'numero'},
        'VALOR_3': {'inicio': 115, 'tamaño': 20, 'tipo': 'numero'},
        'VALOR_4': {'inicio': 135, 'tamaño': 20, 'tipo': 'numero'},
        'VALOR_5': {'inicio': 155, 'tamaño': 20, 'tipo': 'numero'},
        'VALOR_6': {'inicio': 175, 'tamaño': 20, 'tipo': 'numero'},
        'VALOR_7': {'inicio': 195, 'tamaño': 20, 'tipo': 'numero'},
        'VALOR_8': {'inicio': 215, 'tamaño': 20, 'tipo': 'numero'},
        'VALOR_9': {'inicio': 235, 'tamaño': 20, 'tipo': 'numero'},
        'TIPO_FIDEICOMISO': {'inicio': 255, 'tamaño': 2, 'tipo': 'texto'},
        'SUBTIPO_FIDEICOMISO': {'inicio': 257, 'tamaño': 4, 'tipo': 'texto'},
        'VALOR_10': {'inicio': 261, 'tamaño': 20, 'tipo': 'numero'},
        'VALOR_11': {'inicio': 281, 'tamaño': 20, 'tipo': 'numero'},
        'VALOR_12': {'inicio': 301, 'tamaño': 20, 'tipo': 'numero'},
        'VALOR_13': {'inicio': 321, 'tamaño': 20, 'tipo': 'numero'},
        'VALOR_14': {'inicio': 341, 'tamaño': 20, 'tipo': 'numero'},
        'VALOR_15': {'inicio': 361, 'tamaño': 20, 'tipo': 'numero'},
        'VALOR_16': {'inicio': 381, 'tamaño': 20, 'tipo': 'numero'},
        'VALOR_17': {'inicio': 401, 'tamaño': 20, 'tipo': 'numero'},
        'VALOR_18': {'inicio': 421, 'tamaño': 20, 'tipo': 'numero'},
        'VALOR_19': {'inicio': 441, 'tamaño': 20, 'tipo': 'numero'},
        'VALOR_20': {'inicio': 461, 'tamaño': 20, 'tipo': 'numero'},
        'VALOR_21': {'inicio': 481, 'tamaño': 20, 'tipo': 'numero'},
        'VALOR_22': {'inicio': 501, 'tamaño': 20, 'tipo': 'numero'},
        'VALOR_23': {'inicio': 521, 'tamaño': 20, 'tipo': 'numero'},
        'VALOR_24': {'inicio': 541, 'tamaño': 20, 'tipo': 'numero'},
        'VALOR_25': {'inicio': 561, 'tamaño': 20, 'tipo': 'numero'},
        'VALOR_26': {'inicio': 581, 'tamaño': 20, 'tipo': 'numero'},
        'VALOR_27': {'inicio': 601, 'tamaño': 20, 'tipo': 'numero'},
        'VALOR_28': {'inicio': 621, 'tamaño': 20, 'tipo': 'numero'},
        'VALOR_29': {'inicio': 641, 'tamaño': 20, 'tipo': 'numero'},
        'VALOR_30': {'inicio': 661, 'tamaño': 20, 'tipo': 'numero'},
        'TIPO_ENTIDAD': {'inicio': 681, 'tamaño': 5, 'tipo': 'numero'},
        'CIUDAD_GEN': {'inicio': 686, 'tamaño': 8, 'tipo': 'texto'},
        'REFERENCIA': {'inicio': 694, 'tamaño': 10, 'tipo': 'texto'},
        'TARIFA': {'inicio': 704, 'tamaño': 5, 'tipo': 'numero'},
        'CIUDAD_INFORMAR': {'inicio': 709, 'tamaño': 8, 'tipo': 'texto'},
        'NOM_CIUDAD_INFORMAR': {'inicio': 717, 'tamaño': 40, 'tipo': 'texto'},
        'IND_TIP': {'inicio': 757, 'tamaño': 3, 'tipo': 'texto'},
        'PERIODO': {'inicio': 760, 'tamaño': 6, 'tipo': 'numero'},
    }

    # Campos obligatorios
    CAMPOS_OBLIGATORIOS = ['AÑO', 'FORMATO', 'TERCERO']

    @staticmethod
    def normalizar(nombre_campo):
        """
        Normaliza nombres de campos a formato UPPER_CASE con guiones bajos.
        
        Args:
            nombre_campo: Nombre del campo a normalizar
            
        Returns:
            Nombre normalizado en mayúsculas
        """
        if not nombre_campo:
            return ""
        return nombre_campo.upper().strip().replace(' ', '_').replace('-', '_')

    @staticmethod
    def validar_campos_obligatorios(datos):
        """
        Valida que todos los campos obligatorios estén presentes.
        
        Args:
            datos: Diccionario con datos del registro
            
        Raises:
            ValueError: Si falta algún campo obligatorio
        """
        campos_faltantes = []
        for campo in TXTBuilder.CAMPOS_OBLIGATORIOS:
            if campo not in datos or not datos[campo]:
                campos_faltantes.append(campo)
        
        if campos_faltantes:
            raise ValueError(
                f"Campos obligatorios faltantes: {', '.join(campos_faltantes)}"
            )

    @staticmethod
    def formatear_campo(valor, tipo, tamaño):
        """
        Formatea un valor según su tipo y tamaño.
        
        Args:
            valor: Valor a formatear
            tipo: Tipo de campo ('texto' o 'numero')
            tamaño: Tamaño máximo del campo
            
        Returns:
            Valor formateado con la longitud exacta
        """
        if valor is None:
            valor = ""

        if tipo == 'texto':
            # RPAD: Texto relleno a la derecha con espacios
            valor_str = str(valor).upper().strip()
            return valor_str[:tamaño].ljust(tamaño)
        
        elif tipo == 'numero':
            # LPAD: Números relleno a la izquierda con ceros
            try:
                valor_texto = str(valor).strip()
                valor_texto = valor_texto.replace(',', '.') if valor_texto else '0'
                valor_num = float(valor_texto)
                valor_int = int(round(valor_num))
                return str(valor_int).zfill(tamaño)
            except (ValueError, TypeError):
                return '0'.zfill(tamaño)
        
        return str(valor)[:tamaño].ljust(tamaño)

    @classmethod
    def generar_linea(cls, datos, especificacion=None):

        if especificacion is None:
            especificacion = cls.CAMPO_SPECS
        else:
            especificacion = {**cls.CAMPO_SPECS, **especificacion}

        cls.validar_campos_obligatorios(datos)

        max_end = max(
            spec['inicio'] - 1 + spec['tamaño']
            for spec in especificacion.values()
        )

        linea = [' '] * max_end

        # RECORRER TODA LA ESPECIFICACION
        for nombre_campo, spec in especificacion.items():

            inicio = spec['inicio'] - 1
            tamaño = spec['tamaño']
            tipo = spec['tipo']

            # si no viene valor usar valor por defecto
            valor = datos.get(nombre_campo)

            if valor is None or valor == '':
                if tipo == 'numero':
                    valor = 0
                else:
                    valor = ''

            valor_formateado = cls.formatear_campo(
                valor,
                tipo,
                tamaño
            )

            for i, char in enumerate(valor_formateado):
                linea[inicio + i] = char

        return ''.join(linea)

    @classmethod
    def generar_archivo_txt(cls, registros, especificacion=None):
        """
        Genera archivo TXT completo con múltiples registros.
        
        Args:
            registros: Lista de diccionarios con datos de registros
            especificacion: Dict personalizado de campos
            
        Returns:
            String con contenido completo del archivo TXT
            
        Raises:
            ValueError: Si hay registros con datos inválidos
        """
        if especificacion is None:
            especificacion = cls.CAMPO_SPECS

        lineas = []
        errores = []

        for idx, registro in enumerate(registros, 1):
            try:
                linea = cls.generar_linea(registro, especificacion)
                lineas.append(linea)
            except ValueError as e:
                errores.append(f"Registro {idx}: {str(e)}")

        if errores:
            raise ValueError(
                f"Errores en generación de TXT:\n" + "\n".join(errores)
            )

        return "\n".join(lineas)
