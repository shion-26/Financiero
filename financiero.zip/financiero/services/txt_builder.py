# -*- coding: utf-8 -*-
from odoo.exceptions import UserError


def texto(v, l):
    """Rellenar campo de texto: trunca a l caracteres, rellena con espacios"""
    v = '' if v is None else str(v)
    return v[:l].ljust(l)


def numero(v, l):
    """Rellenar campo numérico: convierte a entero, rellena con ceros a la izquierda"""
    try:
        v = int(round(float(v)))
    except (ValueError, TypeError):
        v = 0
    return str(v).zfill(l)[-l:]


def normalizar(nombre):
    """Normalizar nombre de campo: espacios, mayúsculas, guiones bajos"""
    return str(nombre or '').strip().upper().replace(' ', '_').replace('-', '_')


def generar_linea(campos, registro, total):
    """
    Generar una línea de texto con ancho fijo según definición de campos
    
    Args:
        campos: lista de definiciones de campo {'nombre', 'inicio', 'tamano', 'tipo', 'obligatorio'}
        registro: diccionario {nombre_campo: valor}
        total: longitud total de la línea
    
    Retorna: string con la línea formateada
    """
    # Normalizar claves del registro
    registro_norm = {normalizar(k): v for k, v in registro.items()}

    # Inicializar línea con espacios
    linea = [' '] * total

    # Procesar cada campo
    for c in campos:
        nombre = normalizar(c['nombre'])

        valor = registro_norm.get(nombre, None)

        # Validar campos obligatorios
        if c.get('obligatorio') and (valor is None or valor == ''):
            raise UserError(f"Campo obligatorio sin valor: {nombre}")

        # Posición en la línea (ajustar a índice 0)
        inicio = int(c['inicio']) - 1
        tam = int(c['tamano'])

        # Determinar tipo de campo
        tipo = str(c.get('tipo', '')).upper()
        if 'NUM' in tipo:
            valor = numero(valor, tam)
        else:
            valor = texto(valor, tam)

        # Escribir valor en la línea
        for i, ch in enumerate(valor):
            if inicio + i < total:
                linea[inicio + i] = ch

    return ''.join(linea)


def generar_txt(campos, longitud_total, registros):
    """
    Generar contenido completo del archivo TXT
    
    Args:
        campos: lista de definiciones de campo
        longitud_total: longitud total de cada línea
        registros: lista de diccionarios con datos
    
    Retorna: (contenido_txt, cantidad_registros)
    """
    lineas = []

    for idx, registro in enumerate(registros):
        try:
            linea = generar_linea(campos, registro, longitud_total)
            lineas.append(linea)
        except UserError as e:
            raise UserError(f"Error en registro {idx + 1}: {str(e)}")

    contenido = '\n'.join(lineas)
    return contenido, len(registros)
