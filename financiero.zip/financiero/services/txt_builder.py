from .txt_specs import CAMPO_SPECS, CAMPOS_OBLIGATORIOS

class TXTBuilder:

    CAMPO_SPECS = CAMPO_SPECS
    CAMPOS_OBLIGATORIOS = CAMPOS_OBLIGATORIOS

    @staticmethod
    def normalizar(nombre_campo):
        if not nombre_campo:
            return ''

        return (
            nombre_campo.upper()
            .strip()
            .replace(' ', '_')
            .replace('-', '_')
        )

    @staticmethod
    def validar_campos_obligatorios(datos):
        campos_faltantes = []

        for campo in TXTBuilder.CAMPOS_OBLIGATORIOS:
            if campo not in datos or not datos[campo]:
                campos_faltantes.append(campo)

        if campos_faltantes:
            raise ValueError(
                f"Campos obligatorios faltantes: {', '.join(campos_faltantes)}"
            )

    @staticmethod
    def formatear_campo(valor, tipo, tamaño):
        if valor is None:
            valor = ''

        # Texto alineado a la izquierda
        if tipo == 'texto':
            valor_str = str(valor).upper().strip()
            return valor_str[:tamaño].ljust(tamaño)

        # Número alineado a la derecha con ceros
        if tipo == 'numero':
            try:
                valor_texto = str(valor).strip()
                valor_texto = valor_texto.replace(',', '.') if valor_texto else '0'

                valor_num = float(valor_texto)
                valor_int = int(round(valor_num))

                return str(valor_int).zfill(tamaño)

            except (ValueError, TypeError):
                return '0'.zfill(tamaño)

        return str(valor)[:tamaño].ljust(tamaño)

    @classmethod
    def generar_linea(cls, datos, especificacion=None):

        if especificacion is None:
            especificacion = cls.CAMPO_SPECS
        else:
            especificacion = {
                **cls.CAMPO_SPECS,
                **especificacion
            }

        cls.validar_campos_obligatorios(datos)

        max_end = max(
            spec['inicio'] - 1 + spec['tamaño']
            for spec in especificacion.values()
        )

        linea = [' '] * max_end

        # Construir línea según especificación
        for nombre_campo, spec in especificacion.items():

            inicio = spec['inicio'] - 1
            tamaño = spec['tamaño']
            tipo = spec['tipo']

            valor = datos.get(nombre_campo)

            if valor in (None, ''):
                valor = 0 if tipo == 'numero' else ''

            valor_formateado = cls.formatear_campo(
                valor,
                tipo,
                tamaño
            )

            for i, char in enumerate(valor_formateado):
                linea[inicio + i] = char

        return ''.join(linea)

    @classmethod
    def generar_archivo_txt(cls, registros, especificacion=None):

        if especificacion is None:
            especificacion = cls.CAMPO_SPECS

        lineas = []
        errores = []

        for idx, registro in enumerate(registros, start=1):
            try:
                lineas.append(
                    cls.generar_linea(registro, especificacion)
                )

            except ValueError as e:
                errores.append(
                    f"Registro {idx}: {str(e)}"
                )

        if errores:
            raise ValueError(
                "Errores en generación de TXT:\n" +
                "\n".join(errores)
            )

        return "\n".join(lineas)