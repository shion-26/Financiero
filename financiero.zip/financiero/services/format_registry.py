# -*- coding: utf-8 -*-
from .formats import formato_5247

FORMATS = {
    '5247': formato_5247.FORMAT_5247,
}


def get_format(code):
    spec = FORMATS.get(str(code))
    if spec is None:
        available = ', '.join(FORMATS.keys())
        raise ValueError(
            f'Formato {code} no implementado aún. Disponibles: {available}'
        )
    return spec
