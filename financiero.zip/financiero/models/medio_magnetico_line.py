from odoo import fields, models, api
from odoo.exceptions import ValidationError


class MedioMagneticoLine(models.Model):
    _name = 'medio.magnetico.line'
    _description = 'Línea de Medio Magnético'
    _order = 'sequence'

    # Referencias
    medio_id = fields.Many2one(
        'medio.magnetico',
        string='Medio Magnético',
        required=True,
        ondelete='cascade'
    )

    # Datos del registro
    sequence = fields.Integer(
        string='Secuencia',
        default=10,
        help='Orden del registro'
    )
    tercero = fields.Char(
        string='Tercero (CC/NIT)',
        required=True,
        size=15,
        help='Cédula o NIT del tercero'
    )
    mandante = fields.Char(
        string='Mandante',
        size=15,
        help='Nombre o identificación del mandante'
    )
    fideicomiso = fields.Char(
        string='Fideicomiso',
        size=20,
        help='Identificación del fideicomiso'
    )

    valor1  = fields.Float(string='Valor 1',  digits=(18, 2))
    valor2  = fields.Float(string='Valor 2',  digits=(18, 2))
    valor3  = fields.Float(string='Valor 3',  digits=(18, 2))
    valor4  = fields.Float(string='Valor 4',  digits=(18, 2))
    valor5  = fields.Float(string='Valor 5',  digits=(18, 2))
    valor6  = fields.Float(string='Valor 6',  digits=(18, 2))
    valor7  = fields.Float(string='Valor 7',  digits=(18, 2))
    valor8  = fields.Float(string='Valor 8',  digits=(18, 2))
    valor9  = fields.Float(string='Valor 9',  digits=(18, 2))
    valor10 = fields.Float(string='Valor 10', digits=(18, 2))
    valor11 = fields.Float(string='Valor 11', digits=(18, 2))
    valor12 = fields.Float(string='Valor 12', digits=(18, 2))
    valor13 = fields.Float(string='Valor 13', digits=(18, 2))
    valor14 = fields.Float(string='Valor 14', digits=(18, 2))
    valor15 = fields.Float(string='Valor 15', digits=(18, 2))
    valor16 = fields.Float(string='Valor 16', digits=(18, 2))
    valor17 = fields.Float(string='Valor 17', digits=(18, 2))
    valor18 = fields.Float(string='Valor 18', digits=(18, 2))
    valor19 = fields.Float(string='Valor 19', digits=(18, 2))
    valor20 = fields.Float(string='Valor 20', digits=(18, 2))
    valor21 = fields.Float(string='Valor 21', digits=(18, 2))
    valor22 = fields.Float(string='Valor 22', digits=(18, 2))
    valor23 = fields.Float(string='Valor 23', digits=(18, 2))
    valor24 = fields.Float(string='Valor 24', digits=(18, 2))
    valor25 = fields.Float(string='Valor 25', digits=(18, 2))
    valor26 = fields.Float(string='Valor 26', digits=(18, 2))
    valor27 = fields.Float(string='Valor 27', digits=(18, 2))
    valor28 = fields.Float(string='Valor 28', digits=(18, 2))
    valor29 = fields.Float(string='Valor 29', digits=(18, 2))
    valor30 = fields.Float(string='Valor 30', digits=(18, 2))

    @api.constrains('tercero')
    def _check_tercero(self):
        for record in self:
            if not record.tercero or not record.tercero.strip():
                raise ValidationError('El campo Tercero es obligatorio')