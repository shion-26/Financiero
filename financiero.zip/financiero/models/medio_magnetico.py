# -*- coding: utf-8 -*-
import base64
from odoo import models, fields, api
from odoo.exceptions import UserError

from ..services.excel_parser import ExcelParser
from ..services.txt_builder import generar_txt


class MedioMagnetico(models.Model):
    _name = 'medio.magnetico'
    _description = 'Medio Magnético Siesa'

    name = fields.Char(compute="_compute_name", store=True)
    anio = fields.Char(required=True, string='Año')
    formato = fields.Char(required=True, string='Formato')
    concepto = fields.Char(string='Concepto')

    archivo_estructura = fields.Binary(required=True, string='Archivo Estructura Excel')
    archivo_estructura_nombre = fields.Char()

    line_ids = fields.One2many('medio.magnetico.line', 'medio_id', string='Líneas')

    archivo_txt = fields.Binary(readonly=True, string='Archivo TXT Generado')
    archivo_txt_nombre = fields.Char(readonly=True, string='Nombre Archivo TXT')

    estado = fields.Selection([
        ('borrador', 'Borrador'),
        ('generado', 'Generado')
    ], default='borrador', string='Estado')

    @api.depends('anio', 'formato')
    def _compute_name(self):
        for r in self:
            r.name = f"{r.anio or ''}-{r.formato or ''}"

    def action_generar_txt(self):
        self.ensure_one()

        if not self.line_ids:
            raise UserError("No hay líneas para generar")

        # Parser del archivo estructura
        parser = ExcelParser(
            base64.b64decode(self.archivo_estructura),
            self.archivo_estructura_nombre
        )

        estructura = parser.obtener_campos()

        registros = []
        for l in self.line_ids:
            registros.append({
                'anio': self.anio,
                'formato': self.formato,
                'concepto': self.concepto or '',
                'tercero': l.numero_documento,
                'mandante': '',
                'ident_fideicomiso': '',
                'valor1': l.valor1,
                'valor5': l.valor5,
            })

        contenido, _ = generar_txt(
            estructura['campos'],
            estructura['longitud_total'],
            registros
        )

        self.write({
            'archivo_txt': base64.b64encode(contenido.encode('latin-1')),
            'archivo_txt_nombre': f"medios_{self.anio}.txt",
            'estado': 'generado'
        })


class MedioMagneticoLine(models.Model):
    _name = 'medio.magnetico.line'
    _description = 'Líneas de Medio Magnético'

    medio_id = fields.Many2one('medio.magnetico', required=True, ondelete='cascade')

    numero_documento = fields.Char(required=True, string='Documento')
    valor1 = fields.Float(string='Valor 1')
    valor5 = fields.Float(string='Valor 5')
