from odoo import fields, models, api
from odoo.exceptions import ValidationError
import base64

from ..services.txt_builder import TXTBuilder


class MedioMagnetico(models.Model):
    """
    Modelo principal para medios magnéticos SIESA.
    Gestiona la generación de archivos TXT con estructura fija.
    """
    _name = 'medio.magnetico'
    _description = 'Medio Magnético SIESA'
    _order = 'anio DESC, formato DESC'

    # Campos básicos
    name = fields.Char(
        string='Nombre',
        compute='_compute_name',
        store=True,
        help='Generado automáticamente: AÑO-FORMATO'
    )
    anio = fields.Char(
        string='Año',
        required=True,
        size=4,
        help='Año del medio magnético (AAAA)'
    )
    formato = fields.Char(
        string='Formato',
        required=True,
        size=10,
        help='Código de formato SIESA'
    )
    concepto = fields.Char(
        string='Concepto',
        size=10,
        help='Concepto o descripción del movimiento'
    )

    # Archivos
    archivo_datos = fields.Binary(
        string='Archivo Datos (Excel)',
        help='Excel con los terceros a importar'
    )
    archivo_datos_name = fields.Char(
        string='Nombre Archivo Datos'
    )
    archivo_txt = fields.Binary(
        string='Archivo TXT Generado',
        readonly=True,
        help='Archivo TXT generado en formato SIESA'
    )
    archivo_txt_name = fields.Char(
        string='Nombre Archivo TXT',
        readonly=True,
        default='medio_magnetico.txt'
    )
    archivo_hash = fields.Char(
        string='Hash Archivo',
        readonly=False,
        help='Hash MD5 del archivo importado para evitar reprocesos'
    )

    # Estado
    estado = fields.Selection(
        [('borrador', 'Borrador'), ('generado', 'Generado')],
        string='Estado',
        default='borrador',
        help='Estado del medio magnético'
    )

    # Líneas de datos
    line_ids = fields.One2many(
        'medio.magnetico.line',
        'medio_id',
        string='Líneas de Datos',
        help='Registros de datos para el archivo magnético'
    )

    @api.depends('anio', 'formato')
    def _compute_name(self):
        """Genera nombre automático: AÑO-FORMATO"""
        for record in self:
            if record.anio and record.formato:
                record.name = f"{record.anio}-{record.formato}"
            else:
                record.name = 'Sin nombre'

    @api.constrains('anio')
    def _check_anio(self):
        """Valida que el año sea numérico de 4 dígitos"""
        for record in self:
            if record.anio and (not record.anio.isdigit() or len(record.anio) != 4):
                raise ValidationError('El año debe ser numérico de 4 dígitos (AAAA)')

    def action_importar_excel(self):
        self.ensure_one()

        if not self.archivo_datos:
            raise ValidationError('Debe adjuntar un archivo Excel antes de importar.')

        archivo_binario = bytes(base64.b64decode(self.archivo_datos))
        nombre_archivo = (self.archivo_datos_name or '').strip().lower()

        filas_raw = self._leer_filas_excel(archivo_binario, nombre_archivo)

        errores, registros_validos = self._validar_filas(filas_raw)

        if errores:
            detalle = "\n".join(f"  • {e}" for e in errores)
            raise ValidationError(
                f"Se encontraron {len(errores)} error(es) en el Excel.\n"
                f"No se guardó ningún dato.\n\n"
                f"{detalle}"
            )

        self.line_ids.unlink()
        self.archivo_txt = False
        self.estado = 'borrador'

        Line = self.env['medio.magnetico.line']
        for reg in registros_validos:
            vals = {'medio_id': self.id, 'tercero': reg['tercero']}
            for i, v in enumerate(reg['valores'], start=1):
                vals[f'valor{i}'] = v
            Line.create(vals)

        return {
            'type': 'ir.actions.act_window',
            'res_model': self._name,
            'res_id': self.id,
            'view_mode': 'form',
            'target': 'current',
        }

    def _leer_filas_excel(self, archivo_binario, nombre_archivo):
        import io

        if nombre_archivo.endswith('.xlsx'):
            import openpyxl
            wb = openpyxl.load_workbook(io.BytesIO(archivo_binario), data_only=True)
            ws = wb.active

            return [
                (idx, list(row))
                for idx, row in enumerate(ws.iter_rows(min_row=2, values_only=True), start=2)
            ]

        elif nombre_archivo.endswith('.xls'):
            import xlrd
            wb = xlrd.open_workbook(file_contents=archivo_binario)
            ws = wb.sheet_by_index(0)

            return [
                (i + 1, ws.row_values(i))
                for i in range(1, ws.nrows)
            ]

        else:
            raise ValidationError('Formato no soportado. Use .xls o .xlsx')

    def _col_letra(self, index_base0):
        letras = ''
        n = index_base0 + 1

        while n > 0:
            n, rem = divmod(n - 1, 26)
            letras = chr(65 + rem) + letras

        return letras

    def _validar_filas(self, filas_raw):
        errores = []
        registros_validos = []

        for idx_fila, row in filas_raw:

            if not row or all(v in (None, '', 0) for v in row):
                continue

            valor_col_a = row[0] if row else None

            if isinstance(valor_col_a, float) and valor_col_a == int(valor_col_a):
                tercero = str(int(valor_col_a))
            else:
                tercero = str(valor_col_a).strip() if valor_col_a not in (None, '') else ''

            if not tercero:
                errores.append(f"Fila {idx_fila}, columna A: Tercero vacío.")
                continue

            valores = []
            fila_con_error = False

            for col_i in range(1, 31):
                letra = self._col_letra(col_i)

                if col_i >= len(row):
                    valores.append(0.0)
                    continue

                raw = row[col_i]

                if raw in (None, ''):
                    valores.append(0.0)
                    continue

                try:
                    valor = float(raw)
                except (ValueError, TypeError):
                    errores.append(
                        f"Fila {idx_fila}, columna {letra}: no numérico → {raw}"
                    )
                    fila_con_error = True
                    continue

                if valor < 0:
                    errores.append(
                        f"Fila {idx_fila}, columna {letra}: negativo → {valor}"
                    )
                    fila_con_error = True
                    continue

                valores.append(valor)

            if not fila_con_error:
                registros_validos.append({
                    'tercero': tercero,
                    'valores': valores
                })

        return errores, registros_validos

    def action_generar_txt(self):
        """
        Acción principal: genera archivo TXT desde líneas de datos.
        Valida estructura y datos antes de generar.
        """
        self.ensure_one()

        # Validar que existan líneas
        if not self.line_ids:
            raise ValidationError('No hay líneas de datos para generar el archivo')

        try:
            # Usar siempre la estructura fija SIESA
            especificacion = TXTBuilder.CAMPO_SPECS

            # Preparar datos de registros
            registros = []
            for line in self.line_ids:
                registro = {
                    'AÑO': self.anio,
                    'FORMATO': self.formato,
                    'CONCEPTO': self.concepto or '',
                    'TERCERO': line.tercero,
                    'MANDANTE': line.mandante or '',
                    'FIDEICOMISO': line.fideicomiso or '',
                    'TIPO_ENTIDAD': 0,
                    'TARIFA': 0,
                    'PERIODO': 0,
                }

                # Agregar valores 1-30
                for i in range(1, 31):
                    campo_name = f'valor{i}'
                    if hasattr(line, campo_name):
                        valor = getattr(line, campo_name, 0)
                        registro[f'VALOR_{i}'] = valor or 0

                registros.append(registro)

            # Generar contenido TXT
            contenido_txt = TXTBuilder.generar_archivo_txt(registros, especificacion)

            # Guardar archivo TXT generado
            self.archivo_txt = base64.b64encode(contenido_txt.encode('utf-8'))
            self.estado = 'generado'

            return {
                'type': 'ir.actions.client',
                'tag': 'reload',
            }

        except Exception as e:
            raise ValidationError(f'Error al generar archivo TXT: {str(e)}')

    def action_descargar_txt(self):
        """Descarga el archivo TXT generado"""
        self.ensure_one()

        if not self.archivo_txt:
            raise ValidationError('No hay archivo TXT generado')

        return {
            'type': 'ir.actions.act_url',
            'url': (
                f'/web/content?model={self._name}'
                f'&id={self.id}'
                f'&field=archivo_txt'
                f'&filename_field=archivo_txt_name'
                f'&download=true'
            ),
            'target': 'self',
        }

    def action_limpiar(self):
        """Limpia el archivo generado y vuelve a estado borrador"""
        self.ensure_one()
        self.archivo_txt = False
        self.estado = 'borrador'


class MedioMagneticoLine(models.Model):
    """
    Modelo de líneas para medios magnéticos.
    Contiene registros individuales de datos SIESA.
    """
    _name = 'medio.magnetico.line'
    _description = 'Línea de Medio Magnético'
    _order = 'sequence'

    # Referencias
    medio_id = fields.Many2one(
        'medio.magnetico',
        string='Medio Magnético',
        required=True,
        ondelete='cascade'
    )

    # Datos del registro
    sequence = fields.Integer(
        string='Secuencia',
        default=10,
        help='Orden del registro'
    )
    tercero = fields.Char(
        string='Tercero (CC/NIT)',
        required=True,
        size=15,
        help='Cédula o NIT del tercero'
    )
    mandante = fields.Char(
        string='Mandante',
        size=15,
        help='Nombre o identificación del mandante'
    )
    fideicomiso = fields.Char(
        string='Fideicomiso',
        size=20,
        help='Identificación del fideicomiso'
    )

    # Valores (30 campos numéricos)
    valor1 = fields.Float(string='Valor 1', digits=(18, 2))
    valor2 = fields.Float(string='Valor 2', digits=(18, 2))
    valor3 = fields.Float(string='Valor 3', digits=(18, 2))
    valor4 = fields.Float(string='Valor 4', digits=(18, 2))
    valor5 = fields.Float(string='Valor 5', digits=(18, 2))
    valor6 = fields.Float(string='Valor 6', digits=(18, 2))
    valor7 = fields.Float(string='Valor 7', digits=(18, 2))
    valor8 = fields.Float(string='Valor 8', digits=(18, 2))
    valor9 = fields.Float(string='Valor 9', digits=(18, 2))
    valor10 = fields.Float(string='Valor 10', digits=(18, 2))
    valor11 = fields.Float(string='Valor 11', digits=(18, 2))
    valor12 = fields.Float(string='Valor 12', digits=(18, 2))
    valor13 = fields.Float(string='Valor 13', digits=(18, 2))
    valor14 = fields.Float(string='Valor 14', digits=(18, 2))
    valor15 = fields.Float(string='Valor 15', digits=(18, 2))
    valor16 = fields.Float(string='Valor 16', digits=(18, 2))
    valor17 = fields.Float(string='Valor 17', digits=(18, 2))
    valor18 = fields.Float(string='Valor 18', digits=(18, 2))
    valor19 = fields.Float(string='Valor 19', digits=(18, 2))
    valor20 = fields.Float(string='Valor 20', digits=(18, 2))
    valor21 = fields.Float(string='Valor 21', digits=(18, 2))
    valor22 = fields.Float(string='Valor 22', digits=(18, 2))
    valor23 = fields.Float(string='Valor 23', digits=(18, 2))
    valor24 = fields.Float(string='Valor 24', digits=(18, 2))
    valor25 = fields.Float(string='Valor 25', digits=(18, 2))
    valor26 = fields.Float(string='Valor 26', digits=(18, 2))
    valor27 = fields.Float(string='Valor 27', digits=(18, 2))
    valor28 = fields.Float(string='Valor 28', digits=(18, 2))
    valor29 = fields.Float(string='Valor 29', digits=(18, 2))
    valor30 = fields.Float(string='Valor 30', digits=(18, 2))

    @api.constrains('tercero')
    def _check_tercero(self):
        """Valida que tercero no esté vacío"""
        for record in self:
            if not record.tercero or not record.tercero.strip():
                raise ValidationError('El campo Tercero es obligatorio')
