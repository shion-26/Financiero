from . import medio_magnetico
