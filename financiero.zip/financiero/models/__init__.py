# -*- coding: utf-8 -*-
from . import medio_magnetico
