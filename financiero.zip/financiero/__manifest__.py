{
    'name': 'Módulo Financiero - Medio Magnético Siesa',
    'version': '1.0',
    'category': 'Finance',
    'summary': 'Generación de archivos de medio magnético formato Siesa',
    'author': 'Financiero Team',
    'depends': ['base'],
    'data': [
        'security/ir.model.access.csv',
        'views/medio_magnetico_views.xml',
    ],
    'installable': True,
    'application': False,
}
