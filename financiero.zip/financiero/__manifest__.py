{
    'name': 'Financiero',
    'version': '18.0.1.1',
    'category': 'Accounting',
    'summary': 'Generador de Medios Magnéticos',
    'author': 'Empresa',
    'depends': ['base'],
    'data': [
        'security/ir.model.access.csv',
        'views/generar_txt_views.xml',
        'views/menu_views.xml',
    ],
    'external_dependencies': {
        'python': ['openpyxl'],
    },
    'installable': True,
    'application': True,
}
